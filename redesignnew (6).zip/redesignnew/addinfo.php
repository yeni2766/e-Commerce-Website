<?php
echo "<p class = 'info' style = 'padding-left:20px; position:relative; bottom: 260px; font-family:quicksand;'> Information<br><br>
Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. Nullam malesuada erat ut turpis. Suspendisse urna viverra non, semper suscipit, posuere a, pede. Donec nec justo eget felis facilisis fermentum. Aliquam porttitor mauris sit amet orci.
<br>
Fabric & care<br>
Faux suede fabric<br>
Gold tone metal hoop handles.<br>
RI branding<br>
Snake print trim interior
Adjustable cross body strap<br>
Height: 31cm; <br> 
Width: 32cm;<br> Depth: 12cm;<br> Handle Drop: 61cm





</p>";





?>