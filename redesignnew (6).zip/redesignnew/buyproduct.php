<?=theheader('Buy it Now')?>
<link href= "https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet">
<link href = "https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel = "stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri&display=swap" rel="stylesheet">
<div class="buyproduct">
    <h1>Thanks for purchasing with us</h1>
    <p> We will contact you by email with your order details very shortly.</p>
</div>

<?=template_footer()?>

<style>


html {
  overflow-x: initial !important;
}

.buyproduct{
position:relative;
left:700px;


}
.buyproduct p{
position:relative;
top:20px;
left:40px;
font-family:quicksand;


}
.buyproduct h1{
position:relative;
left:50px;
font-family:quicksand;


}


  html, body {
    max-width: 100%;
    overflow-x: hidden;
}

</style>
<style>
@media only screen and (max-width: 1366px){
	.buyproduct{
position:relative;
left:450px;


}
.buyproduct p{
position:relative;
top:20px;
right:30px;
font-family:quicksand;


}
.buyproduct h1{
position:relative;
left:50px;
font-family:quicksand;


}
}
</style>